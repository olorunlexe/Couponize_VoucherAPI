﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using VoucherDependencies.Models;

namespace Couponize_Voucher_API.Models
{
    public class Voucher
    {
        private string code;
        private string voucher_type;
        private string category;
        private string additional_Info;
        private DateTime start_Date;
        private DateTime expiration_Date;
        private bool active;

        public string GetCode()
        {
            return code;
        }

        public void SetCode(string value)
        {
            code = value;
        }

        public string GetVoucherType()
        {
            return voucher_type;
        }

        public void SetVoucherType(string value)
        {
            voucher_type = value;
        }

        public string GetCategory()
        {
            return category;
        }

        public void SetCategory(string value)
        {
            category = value;
        }

        public string GetAdditional_Info()
        {
            return additional_Info;
        }

        public void SetAdditional_Info(string value)
        {
            additional_Info = value;
        }

        public DateTime GetStart_Date()
        {
            return start_Date;
        }

        public void SetStart_Date(DateTime value)
        {
            start_Date = value;
        }

        public DateTime GetExpiration_Date()
        {
            return expiration_Date;
        }

        public void SetExpiration_Date(DateTime value)
        {
            expiration_Date = value;
        }

        public bool GetActive()
        {
            return active;
        }

        public void SetActive(bool value)
        {
            active = value;
        }
        public override string ToString()
        {
            return base.ToString();
        }
    }
}
