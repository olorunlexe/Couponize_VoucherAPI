﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoucherDependencies.Models
{
    public class Gift
    {
        private int amount;

        public int GetAmount()
        {
            return amount;
        }

        public void SetAmount(int value)
        {
            amount = value;
        }
    }
}
