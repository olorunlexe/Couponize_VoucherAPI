﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VoucherDependencies.Models
{
    public class Discount
    {
        private string discount_type;
        private float percent_Off;
        private int amount_Off;
        private readonly int amount_Limit1;
        private float unit_Off;
        private string unit_Type;

        public Discount (string discount_type, float percent_Off, int amountLimit)
        {

        }

        public Discount (string discount_type, int amount_off)
        {

        }

        public Discount(string discount_Type, float unit_off, string unit_type)
        {

        }

        public string GetDiscountType()
        {
            return discount_type;
        }

        public float GetPercent_Off()
        {
            return percent_Off;
        }

        

        private int Getamount_Limit()
        {
            return amount_Limit1;
        }

        public int GetAmount_Off()
        {
            return amount_Off;
        }

        public float GetUnit_Off()
        {
            return unit_Off;
        }

        public string GetUnit_Type()
        {
            return unit_Type;
        }
        
        public override string ToString()
        {
            return base.ToString();
        }
    }
}
